/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.booksys.dao;

import com.booksys.model.HoaDon;
import com.booksys.utils.XJdbcHelper;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PC
 */
public class HoaDonDAO {
    Connection con = XJdbcHelper.getConnection();
    String getAll = "select * from HoaDon";
    String insert = "exec proc_ThemHoaDon ?, ?, ?, ?";
    String update = "exec proc_SuaHoaDon ?, ?, ?, ?";
    String delete = "exec proc_XoaHoaDon ?";
    
    public List<HoaDon> getAll(){
        List<HoaDon> list = new ArrayList();
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(getAll);
            
            while(rs.next()){
                HoaDon hd = new HoaDon();
                hd.setMaHD(rs.getString(1));
                hd.setMaNV(rs.getString(2));
                hd.setMaKH(rs.getString(3));
                hd.setNgayLap(rs.getDate(4));
                list.add(hd);
            }
        } catch (Exception e) {
        }
        return list;
    }
    public void insertHoaDon(String MaHD, String MaNV, String MaKH, Date NgayLap) {
        try {
            PreparedStatement pr = con.prepareStatement(insert);

            pr.setString(1, MaHD);
            pr.setString(2, MaNV);
            pr.setString(3, MaKH);
            pr.setDate(4, NgayLap);
            pr.executeUpdate();
            pr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void deleteHoaDon(String MaHD){
        try {
            PreparedStatement pr = con.prepareStatement(delete);

            pr.setString(1, MaHD);
            pr.executeUpdate();
            pr.close();
        } catch (Exception e) {
        }
    }
}
