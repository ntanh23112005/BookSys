package com.booksys.dao;

import com.booksys.model.HoaDonCuaKhach;
import com.booksys.model.NhanVien;
import com.booksys.utils.XJdbcHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class NhanVienDAO {
    Connection con = XJdbcHelper.getConnection();
    String getAll = "select * from NhanVien";
    String getTheoMaNV = "select * from NhanVien where MaNV = ?";
    String getTheoKey = "select * from NhanVien nv where nv.TenNV like ?";
    String getHDQL = "	select hd.MaHD, hd.MaNV, hd.NgayLap, cthd.TrangThai, hd.MaKH, sum(cthd.TongTien) from HoaDon hd\n" +
                        "inner join ChiTietHoaDon cthd on hd.MaHD = cthd.MaHD\n" +
                        "inner join KhachHang kh on hd.MaKH = kh.MaKH\n" +
                        "where hd.MaHD = ?\n" +
                        "group by hd.MaHD, hd.MaNV, hd.NgayLap, cthd.TrangThai, hd.MaKH";
    String getAllSumTongTien = "select hd.MaHD, hd.MaNV, hd.NgayLap, cthd.TrangThai, hd.MaKH, sum(cthd.TongTien) from HoaDon hd \n" +
                            "	inner join ChiTietHoaDon cthd on hd.MaHD = cthd.MaHD\n" +
                            "	inner join KhachHang kh on hd.MaKH = kh.MaKH\n" +
                            "	group by hd.MaHD, hd.MaNV, hd.NgayLap, cthd.TrangThai, hd.MaKH";
    String getAllSumSach = "select hd.MaHD, hd.MaNV, hd.NgayLap, cthd.TrangThai, hd.MaKH, sum(cthd.TongTien), s.MaSach, s.TenSach, cthd.SoLuong from HoaDon hd \n" +
                            "	inner join ChiTietHoaDon cthd on hd.MaHD = cthd.MaHD\n" +
                            "	inner join KhachHang kh on hd.MaKH = kh.MaKH\n" +
                            "	inner join Sach s on cthd.MaSach = s.MaSach\n" +
                            "	where hd.MaHD = ?\n" +
                            "	group by hd.MaHD, hd.MaNV, hd.NgayLap, cthd.TrangThai, hd.MaKH, s.MaSach, s.TenSach, cthd.SoLuong";
    String insert = "exec proc_ThemNhanVien ?, ?, ?, ?, ?, ?, ?";
    String update = "exec proc_SuaNhanVien ?, ?, ?, ?, ?, ?, ?, ?";
    String delete = "exec proc_XoaNhanVien ?";
    String checkLogin = "SELECT * FROM NhanVien WHERE MaNV = ? AND MatKhau = ?";
    String getMaNV = "select  MaNV from NhanVien where MaNV = ?";

    public List<NhanVien> getAll() {
        List<NhanVien> list = new ArrayList<>();
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(getAll)) {
            while (rs.next()) {
                NhanVien nv = new NhanVien();
                nv.setMaNV(rs.getString(1));
                nv.setTenNV(rs.getString(2));
                nv.setEmail(rs.getString(3));
                nv.setSdt(rs.getString(4));
                nv.setNgaySinh(java.sql.Date.valueOf(rs.getString(5)));
                nv.setVaiTro(rs.getString(6));
                nv.setMatKhau(rs.getString(7));
                nv.setHinh(rs.getString(8));
                list.add(nv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<NhanVien> getTheoMaNV(String maNV) {
        List<NhanVien> list = new ArrayList<>();
        try (PreparedStatement pr = con.prepareStatement(getTheoMaNV)) {
            pr.setString(1, maNV);
            try (ResultSet rs = pr.executeQuery()) {
                while (rs.next()) {
                    NhanVien nv = new NhanVien();
                    nv.setMaNV(rs.getString(1));
                    nv.setTenNV(rs.getString(2));
                    nv.setEmail(rs.getString(3));
                    nv.setSdt(rs.getString(4));
                    nv.setNgaySinh(rs.getDate(5));
                    nv.setVaiTro(rs.getString(6));
                    nv.setMatKhau(rs.getString(7));
                    nv.setHinh(rs.getString(8));
                    list.add(nv);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<NhanVien> getTheoKey(String tennv) {
        List<NhanVien> list = new ArrayList<>();
        try (PreparedStatement pr = con.prepareStatement(getTheoKey)) {
            pr.setString(1, "%" + tennv + "%");
            try (ResultSet rs = pr.executeQuery()) {
                while (rs.next()) {
                    NhanVien nv = new NhanVien();
                    nv.setMaNV(rs.getString(1));
                    nv.setTenNV(rs.getString(2));
                    nv.setEmail(rs.getString(3));
                    nv.setSdt(rs.getString(4));
                    nv.setNgaySinh(rs.getDate(5));
                    nv.setVaiTro(rs.getString(6));
                    nv.setMatKhau(rs.getString(7));
                    nv.setHinh(rs.getString(8));
                    list.add(nv);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<HoaDonCuaKhach> getHDQL(String mahd) {
        List<HoaDonCuaKhach> list = new ArrayList<>();
        try (PreparedStatement pr = con.prepareStatement(getHDQL)) {
            pr.setString(1, mahd);
            try (ResultSet rs = pr.executeQuery()) {
                while (rs.next()) {
                    HoaDonCuaKhach hd = new HoaDonCuaKhach();
                    hd.setMaHD(rs.getString(1));
                    hd.setMaNV(rs.getString(2));
                    hd.setNgayLap(rs.getDate(3));
                    hd.setTrangthai(rs.getString(4));
                    hd.setMaKH(rs.getString(5));
                    hd.setTongTien(rs.getDouble(6));
                    list.add(hd);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<HoaDonCuaKhach> getAllHDSumTongTien() {
        List<HoaDonCuaKhach> list = new ArrayList<>();
        try (Statement st = con.createStatement(); 
             ResultSet rs = st.executeQuery(getAllSumTongTien)) {
            while (rs.next()) {
                HoaDonCuaKhach hd = new HoaDonCuaKhach();
                hd.setMaHD(rs.getString(1));
                hd.setMaNV(rs.getString(2));
                hd.setNgayLap(rs.getDate(3));
                hd.setTrangthai(rs.getString(4));
                hd.setMaKH(rs.getString(5));
                hd.setTongTien(rs.getDouble(6));
                list.add(hd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<HoaDonCuaKhach> getHDSumSach(String mahd) {
        List<HoaDonCuaKhach> list = new ArrayList<>();
        try (PreparedStatement pr = con.prepareStatement(getAllSumSach)) {
            pr.setString(1, mahd);
            try (ResultSet rs = pr.executeQuery()) {
                while (rs.next()) {
                    HoaDonCuaKhach hd = new HoaDonCuaKhach();
                    hd.setMaHD(rs.getString(1));
                    hd.setMaNV(rs.getString(2));
                    hd.setNgayLap(rs.getDate(3));
                    hd.setTrangthai(rs.getString(4));
                    hd.setMaKH(rs.getString(5));
                    hd.setTongTien(rs.getDouble(6));
                    hd.setMaSach(rs.getString(7));
                    hd.setTenSach(rs.getString(8));
                    hd.setSoLuong(rs.getString(9));
                    list.add(hd);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public boolean insert(NhanVien nv) {
        try (PreparedStatement ps = con.prepareStatement(insert)) {
            ps.setString(1, nv.getTenNV());
            ps.setString(2, nv.getEmail());
            ps.setString(3, nv.getSdt());
            ps.setDate(4, nv.getNgaySinh());
            ps.setString(5, nv.getVaiTro());
            ps.setString(6, nv.getMatKhau());
            ps.setString(7, nv.getHinh());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean update(NhanVien nv) {
        try (PreparedStatement ps = con.prepareStatement(update)) {
            ps.setString(1, nv.getMaNV());
            ps.setString(2, nv.getTenNV());
            ps.setString(3, nv.getEmail());
            ps.setString(4, nv.getSdt());
            ps.setDate(5, nv.getNgaySinh());
            ps.setString(6, nv.getVaiTro());
            ps.setString(7, nv.getMatKhau());
            ps.setString(8, nv.getHinh());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean delete(String maNV) {
        try (PreparedStatement ps = con.prepareStatement(delete)) {
            ps.setString(1, maNV);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    //hàm check đăng nhập nhân viên
    public List<NhanVien> checkLogin(String user,String pass){
        List<NhanVien> listLog = new ArrayList<>();
        try {
            PreparedStatement pr = con.prepareStatement(checkLogin);
            pr.setString(1, user);
            pr.setString(2, pass);
            
            ResultSet rs = pr.executeQuery();
            if(rs.next()){
                NhanVien nv = new NhanVien();
                nv.setMaNV(rs.getString(1));
                nv.setTenNV(rs.getString(2));
                nv.setEmail(rs.getString(3));
                nv.setSdt(rs.getString(4));
                nv.setNgaySinh(java.sql.Date.valueOf(rs.getString(5)));
                nv.setVaiTro(rs.getString(6));
                nv.setMatKhau(rs.getString(7));
                nv.setHinh(rs.getString(8));
                listLog.add(nv);
            }
            pr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listLog;
    }

    
    public String getMaNV(String user){
        String maNhanVien = null;
        
        try {
            PreparedStatement pr = con.prepareStatement(getMaNV);
            pr.setString(1, user);
            
            ResultSet rs = pr.executeQuery();
            
            if(rs.next()){
                maNhanVien = rs.getString("MaNV");
            }
            pr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return maNhanVien;
    }
    
}
