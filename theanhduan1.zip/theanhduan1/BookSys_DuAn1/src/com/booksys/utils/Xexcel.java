/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.booksys.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author PC
 */
// đang trong giai đoạn test vẫn chưa xài được !!!!!!!
public class Xexcel {
    public void ExportExcel(String tenSheet, int soCot, List<String> tenCot, List<Object> mangData){
        XSSFWorkbook swb = new XSSFWorkbook();
        XSSFSheet xSheet = swb.createSheet(tenSheet);
        XSSFRow row = null;
        Cell cell = null;
        row = xSheet.createRow(soCot);
        for (int i = 0; i < soCot; i++) {
            cell = row.createCell(i, CellType.STRING);
            cell.setCellValue(tenCot.get(i));
        }
        
//        for (int i = 0; i < dao.selectAll().size(); i++) {
//            Sach s = dao.selectAll().get(i);
//            row = xSheet.createRow(5 + i);
//            
//            cell = row.createCell(0, CellType.STRING);
//            cell.setCellValue(dao.selectAll().get(i).getMas());
//            
//            cell = row.createCell(1, CellType.STRING);
//            cell.setCellValue(dao.selectAll().get(i).getTens());
//            
//            cell = row.createCell(2, CellType.STRING);
//            cell.setCellValue(dao.selectAll().get(i).getGias());
//            
//            cell = row.createCell(3, CellType.STRING);
//            cell.setCellValue(dao.selectAll().get(i).getHinhs());
//        }
        File f = new File("E:\\danhsachsanpham.xlsx");
        try{
            FileOutputStream fis = new FileOutputStream(f);
            swb.write(fis);
            fis.close();
        } catch (Exception e){
            
        }
        System.out.println();
    }
    public List<String> readListTenCot(String tenCot){
        List<String> list = new ArrayList();
        String [] s = tenCot.trim().split(",");
        for (String str : s) {
            list.add(str.trim());
        }
        return list;
    }
    public List<Object> readListData(String data){
        List<Object> list = new ArrayList();
        String [] s = data.trim().split("-");
        for (String str : s) {
            String[] ts = str.trim().split(",");
            list.add(ts);
        }
        return list;
    }
}
