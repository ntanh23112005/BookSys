/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.booksys.dao;

import com.booksys.model.HoaDonCuaKhach;
import com.booksys.model.KhachHang;
import com.booksys.ui.Login;
import com.booksys.utils.XJdbcHelper;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PC
 */
public class KhachHangDAO {
    private Connection con = XJdbcHelper.getConnection();
    private String getAll = "SELECT * FROM KhachHang";
    private String getHDTheoMaKH = "exec proc_getHDTheoMaKH ?";
    private String getHoaDonKhach = "EXEC proc_SelectHodonKhach ?, ?";
    private String getChiTietHoaDon = "EXEC proc_SelectChiTietHoaDonCuaKhach ?, ?";
    private String insert = "EXEC proc_ThemKhachHang ?, ?, ?, ?, ?, ?, ?, ?";
    private String update = "exec proc_SuaKhachHang ?, ?, ?, ?, ?, ?, ?, ?, ?";
    private String delete = "EXEC proc_XoaNhanVien ?";
    private String getTheoMaKH = "SELECT * FROM KhachHang WHERE MaKH = ?";
    private String login = "EXEC proc_loginKH ?, ?";

    public List<KhachHang> getAll() {
        List<KhachHang> list = new ArrayList<>();
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(getAll)) {
            while (rs.next()) {
                KhachHang kh = new KhachHang();
                kh.setMaKH(rs.getString(1));
                kh.setTenTK(rs.getString(2));
                kh.setHoTen(rs.getString(3));
                kh.setSdt(rs.getString(4));
                kh.setMatKhau(rs.getString(5));
                kh.setEmail(rs.getString(6));
                kh.setDiaChi(rs.getString(7));
                kh.setHinh(rs.getString(8));
                kh.setNgaySinh(rs.getDate(9));
                list.add(kh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<KhachHang> getByIDMaKH(String MaKH) {
        List<KhachHang> list = new ArrayList<>();
        try (PreparedStatement pr = con.prepareStatement(getTheoMaKH)) {
            pr.setString(1, MaKH);
            try (ResultSet rs = pr.executeQuery()) {
                while (rs.next()) {
                    KhachHang kh = new KhachHang();
                    kh.setMaKH(rs.getString(1));
                    kh.setTenTK(rs.getString(2));
                    kh.setHoTen(rs.getString(3));
                    kh.setSdt(rs.getString(4));
                    kh.setMatKhau(rs.getString(5));
                    kh.setEmail(rs.getString(6));
                    kh.setDiaChi(rs.getString(7));
                    kh.setHinh(rs.getString(8));
                    kh.setNgaySinh(rs.getDate(9));
                    list.add(kh);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<KhachHang> loginKH(String tenTK, String matKhau) {
        List<KhachHang> list = new ArrayList<>();
        try (PreparedStatement pr = con.prepareStatement(login)) {
            pr.setString(1, tenTK);
            pr.setString(2, matKhau);
            try (ResultSet rs = pr.executeQuery()) {
                while (rs.next()) {
                    KhachHang kh = new KhachHang();
                    kh.setMaKH(rs.getString(1));
                    kh.setTenTK(rs.getString(2));
                    kh.setHoTen(rs.getString(3));
                    kh.setSdt(rs.getString(4));
                    kh.setMatKhau(rs.getString(5));
                    kh.setEmail(rs.getString(6));
                    kh.setDiaChi(rs.getString(7));
                    kh.setHinh(rs.getString(8));
                    kh.setNgaySinh(rs.getDate(9));
                    list.add(kh);
                }
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<HoaDonCuaKhach> getHDTheoMaKH(String maKH) {
        List<HoaDonCuaKhach> list = new ArrayList<>();
        try (PreparedStatement pr = con.prepareStatement(getHDTheoMaKH)) {
            pr.setString(1, maKH);
            try (ResultSet rs = pr.executeQuery()) {
                while (rs.next()) {
                    HoaDonCuaKhach hd = new HoaDonCuaKhach();
                    hd.setMaHD(rs.getString(1));
                    hd.setNgayLap(rs.getDate(2));
                    hd.setTongTien(rs.getDouble(3));
                    hd.setTrangthai(rs.getString(4));
                    hd.setMaKH(rs.getString(5));
                    list.add(hd);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<HoaDonCuaKhach> getSumTienSol(String MaHD, String MaKH) {
        List<HoaDonCuaKhach> list = new ArrayList<>();
        try (PreparedStatement pr = con.prepareStatement(getHoaDonKhach)) {
            pr.setString(1, MaHD);
            pr.setString(2, MaKH);
            try (ResultSet rs = pr.executeQuery()) {
                while (rs.next()) {
                    HoaDonCuaKhach hd = new HoaDonCuaKhach();
                    hd.setMaHD(rs.getString(1));
                    hd.setNgayLap(rs.getDate(2));
                    hd.setTongTien(rs.getDouble(3));
                    hd.setSoLuong(rs.getString(4));
                    hd.setTrangthai(rs.getString(5));
                    list.add(hd);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<HoaDonCuaKhach> getChiTietHD(String MaHD, String MaKH) {
        List<HoaDonCuaKhach> list = new ArrayList<>();
        try (PreparedStatement pr = con.prepareStatement(getChiTietHoaDon)) {
            pr.setString(1, MaHD);
            pr.setString(2, MaKH);
            try (ResultSet rs = pr.executeQuery()) {
                while (rs.next()) {
                    HoaDonCuaKhach hd = new HoaDonCuaKhach();
                    hd.setMaHD(rs.getString(1));
                    hd.setNgayLap(rs.getDate(2));
                    hd.setMaSach(rs.getString(3));
                    hd.setTenSach(rs.getString(4));
                    hd.setSoLuong(rs.getString(5));
                    hd.setTongTien(rs.getDouble(6));
                    hd.setTrangthai(rs.getString(7));
                    list.add(hd);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void insertKhachHang(KhachHang kh) {
        try (PreparedStatement pr = con.prepareStatement(insert)) {
            pr.setString(1, kh.getTenTK());
            pr.setString(2, kh.getHoTen());
            pr.setString(3, kh.getSdt());
            pr.setString(4, kh.getMatKhau());
            pr.setString(5, kh.getEmail());
            pr.setString(6, kh.getDiaChi());
            pr.setString(7, kh.getHinh());
            pr.setDate(8, (Date) kh.getNgaySinh());
            pr.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateKhachHang(KhachHang kh) {
        try (PreparedStatement pr = con.prepareStatement(update)) {
            pr.setString(1, kh.getMaKH());
            pr.setString(2, kh.getTenTK());
            pr.setString(3, kh.getHoTen());
            pr.setString(4, kh.getSdt());
            pr.setString(5, kh.getMatKhau());
            pr.setString(6, kh.getEmail());
            pr.setString(7, kh.getDiaChi());
            pr.setString(8, kh.getHinh());
            pr.setDate(9, (Date) kh.getNgaySinh());
            pr.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(KhachHang kh) {
        try (PreparedStatement pr = con.prepareStatement(delete)) {
            pr.setString(1, kh.getMaKH());
            pr.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
