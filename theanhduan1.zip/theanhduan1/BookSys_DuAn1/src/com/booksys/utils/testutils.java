/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.booksys.utils;

import com.booksys.dao.KhachHangDAO;
import com.booksys.model.KhachHang;
import java.util.Arrays;
import java.util.List;
import java.math.BigDecimal;

/**
 *
 * @author PC
 */
public class testutils {
    public static void main(String[] args) {
        System.out.println("hahah  hahah");
    }
}
