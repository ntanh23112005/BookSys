/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.booksys.model;

import java.util.Date;

/**
 *
 * @author PC
 */
public class KhuyenMai {

    private String maKhuyenMai;
    private double giamBaoNhieu;
    private Date ngayBatDau;
    private Date ngayKetThuc;
    private String ghiChu;
    private String tinhTrang;
    private String maNV;

    public KhuyenMai() {
    }
    

    public KhuyenMai(String maKhuyenMai, double giamBaoNhieu, Date ngayBatDau, Date ngayKetThuc, String ghiChu, String tinhTrang, String maNV) {
        this.maKhuyenMai = maKhuyenMai;
        this.giamBaoNhieu = giamBaoNhieu;
        this.ngayBatDau = ngayBatDau;
        this.ngayKetThuc = ngayKetThuc;
        this.ghiChu = ghiChu;
        this.tinhTrang = tinhTrang;
        this.maNV = maNV;
    }

    public String getMaKhuyenMai() {
        return maKhuyenMai;
    }

    public void setMaKhuyenMai(String maKhuyenMai) {
        this.maKhuyenMai = maKhuyenMai;
    }

    public double getGiamBaoNhieu() {
        return giamBaoNhieu;
    }

    public void setGiamBaoNhieu(double giamBaoNhieu) {
        this.giamBaoNhieu = giamBaoNhieu;
    }

    public Date getNgayBatDau() {
        return ngayBatDau;
    }

    public void setNgayBatDau(Date ngayBatDau) {
        this.ngayBatDau = ngayBatDau;
    }

    public Date getNgayKetThuc() {
        return ngayKetThuc;
    }

    public void setNgayKetThuc(Date ngayKetThuc) {
        this.ngayKetThuc = ngayKetThuc;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    public String getTinhTrang() {
        return tinhTrang;
    }

    public void setTinhTrang(String tinhTrang) {
        this.tinhTrang = tinhTrang;
    }

    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }
}
