package com.booksys.dao;

import com.booksys.utils.XJdbcHelper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ThongBaoMuaHangDAO {
    private Connection con = XJdbcHelper.getConnection();

    // Stored Procedure SQL
    String insertProcedure = "EXEC proc_ThemThongBaoMuaHang ?, ?";
    String deleteProcedure = "EXEC proc_XoaThongBaoMuaHang ?";

    // Thêm thông báo mua hàng
    public void insertThongBaoMuaHang(String maKH, String noiDung) {
        try {
            PreparedStatement pr = con.prepareStatement(insertProcedure);
            pr.setString(1, maKH);
            pr.setString(2, noiDung);
            pr.executeUpdate();
            pr.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Xóa thông báo mua hàng
    public void deleteThongBaoMuaHang(String maKH) {
        try {
            PreparedStatement pr = con.prepareStatement(deleteProcedure);
            pr.setString(1, maKH);
            pr.executeUpdate();
            pr.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
