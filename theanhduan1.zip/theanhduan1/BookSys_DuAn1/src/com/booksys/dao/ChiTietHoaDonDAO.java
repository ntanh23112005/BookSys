/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.booksys.dao;

import com.booksys.model.ChiTietHoaDon;
import com.booksys.utils.XJdbcHelper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author PC
 */


public class ChiTietHoaDonDAO {
    Connection con = XJdbcHelper.getConnection();
    String getAll = "SELECT * FROM ChiTietHoaDon";
    String insert = "EXEC proc_ThemChiTietHoaDon ?, ?, ?, ?, ?";
    String update = "EXEC proc_SuaChiTietHoaDon ?, ?, ?, ?, ?";
    String delete = "EXEC proc_XoaChiTietHoaDon ?, ?";

    public List<ChiTietHoaDon> getAll() {
        List<ChiTietHoaDon> list = new ArrayList<>();
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(getAll);

            while (rs.next()) {
                ChiTietHoaDon cthd = new ChiTietHoaDon();
                cthd.setMaHD(rs.getString(1));
                cthd.setMaSach(rs.getString(2));
                cthd.setSoLuong(rs.getInt(3));
                cthd.setTongTien(rs.getDouble(4));
                cthd.setTrangThai(rs.getString(5));
                list.add(cthd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void insertChiTietHoaDon(String MaHD, String MaSach, int SoLuong, double TongTien, String trangThai) {
        try {
            PreparedStatement pr = con.prepareStatement(insert);

            pr.setString(1, MaHD);
            pr.setString(2, MaSach);
            pr.setInt(3, SoLuong);
            pr.setDouble(4, TongTien);
            pr.setString(5, trangThai);
            pr.executeUpdate();
            pr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//    public void updateChiTietHoaDon(String MaHD, String MaSach, BigDecimal SoLuong, BigDecimal TongTien) {
//        try {
//            PreparedStatement pr = con.prepareStatement(update);
//
//            pr.setString(1, MaHD);
//            pr.setString(2, MaSach);
//            pr.setBigDecimal(3, SoLuong);
//            pr.setBigDecimal(4, TongTien);
//            pr.executeUpdate();
//            pr.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    public void deleteChiTietHoaDon(String MaHD, String MaSach) {
        try {
            PreparedStatement pr = con.prepareStatement(delete);

            pr.setString(1, MaHD);
            pr.setString(2, MaSach);
            pr.executeUpdate();
            pr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public List<ChiTietHoaDon> getAllByMaHD(String maHD){
        List<ChiTietHoaDon> listCTHD = new ArrayList<>();
        try {
            String sql = "select * from ChiTietHoaDon where MaHD = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(1 , maHD);
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                ChiTietHoaDon cthd = new ChiTietHoaDon();
                cthd.setMaHD(rs.getString(1));
                cthd.setMaSach(rs.getString(2));
                cthd.setSoLuong(rs.getInt(3));
                cthd.setTongTien(rs.getDouble(4));
                cthd.setTrangThai(rs.getString(5));
                listCTHD.add(cthd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listCTHD;
    }
}
