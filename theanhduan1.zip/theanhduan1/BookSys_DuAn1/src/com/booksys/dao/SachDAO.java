/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.booksys.dao;

import com.booksys.model.KhuyenMai;
import com.booksys.model.Sach;
import com.booksys.utils.XJdbcHelper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PC
 */
public class SachDAO {

    Connection con = XJdbcHelper.getConnection();
    String getAll = "select * from Sach";
    String getTheoMaSach = "exec proc_timTheoMaSach ?";
    String getTheLoai = "select TheLoai from Sach\n" + "group by TheLoai";
    String getTheMaKhuyenMai = "select MaKhuyenMai, GiamBaoNhieu from KhuyenMai\n" +"group by MaKhuyenMai, GiamBaoNhieu";
    String getTheoTenSach = "	select * from Sach where TenSach like ?";
    String getSumSoluongSachDaBan = "select cthd.MaSach, sum(cthd.SoLuong) from ChiTietHoaDon cthd\n" +
                                    "group by cthd.MaSach";
    String getSachBanChay = "select * from Sach \n" +
                            "where MaSach in (select cthd.MaSach from ChiTietHoaDon cthd\n" +
                            "group by cthd.MaSach\n" +
                            "having sum(cthd.SoLuong) > 10)";
    String getSachBanE = "select * from Sach \n" +
                        "where MaSach in (	select cthd.MaSach from ChiTietHoaDon cthd\n" +
                        "group by cthd.MaSach\n" +
                        "having sum(cthd.SoLuong) < 5)";
    String getSachCoLuongMuaNhieuNhat = "SELECT TOP 1 s.MaSach, s.TenSach, s.TheLoai, s.GiaNhap, s.GiaBan,SUM(cthd.SoLuong) AS TongSoLuong, s.MaNV, s.MaKhuyenMai, s.Hinh \n" +
                                        "FROM Sach s\n" +
                                        "INNER JOIN ChiTietHoaDon cthd ON s.MaSach = cthd.MaSach\n" +
                                        "GROUP BY s.MaSach, s.TenSach, s.TheLoai, s.GiaNhap, s.GiaBan, s.MaNV, s.MaKhuyenMai, s.Hinh\n" +
                                        "ORDER BY TongSoLuong DESC;";
    String getSachCoGiamGia = "select * from Sach where MaKhuyenMai != 'Null'";
    String getSachSoluongConLai = "select * from Sach s\n" +
                                  "where s.SoLuong  between ? and ?";
    String getSoluongSachTheoYeuCau = "select * from Sach s\n" +
"where s.SoLuong  between 0 and 10";
    String insert = "exec proc_ThemSach ?, ?, ?, ?, ?, ?, ?, ?";
    String update = "exec proc_SuaSach ?, ?, ?, ?, ?, ?, ?, ?, ?";
    String delete = "exec proc_XoaSach ?";

    public List<Sach> getAllSach() {
        List<Sach> list = new ArrayList<>();
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(getAll);
            while (rs.next()) {
                Sach sach = new Sach();
                sach.setMaSach(rs.getString(1));
                sach.setTenSach(rs.getString(2));
                sach.setTheLoai(rs.getString(3));
                sach.setGiaNhap(rs.getDouble(4));
                sach.setGiaBan(rs.getDouble(5));
                sach.setSoLuong(rs.getInt(6));
                sach.setMaNV(rs.getString(7));
                sach.setMaKhuyenMai(rs.getString(8));
                sach.setHinh(rs.getString(9));
                list.add(sach);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
    
    public List<Sach> getTheLoai() {
        List<Sach> list = new ArrayList<>();
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(getTheLoai);
            while (rs.next()) {
                Sach sach = new Sach();
                sach.setTheLoai(rs.getString(1));
                list.add(sach);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
    
    public List<KhuyenMai> getMaKhuyenMai() {
        List<KhuyenMai> list = new ArrayList<>();
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(getTheMaKhuyenMai);
            while (rs.next()) {
                KhuyenMai km = new KhuyenMai();
                km.setMaKhuyenMai(rs.getString(1));
                km.setGiamBaoNhieu(rs.getDouble(2));
                list.add(km);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
    
    public List<Sach> getTheoMaSach(String maSach) {
        List<Sach> list = new ArrayList<>();
        try {
            PreparedStatement pr = con.prepareStatement(getTheoMaSach);
            pr.setString(1, maSach);
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                Sach sach = new Sach();
                sach.setMaSach(rs.getString(1));
                sach.setTenSach(rs.getString(2));
                sach.setTheLoai(rs.getString(3));
                sach.setGiaNhap(rs.getDouble(4));
                sach.setGiaBan(rs.getDouble(5));
                sach.setSoLuong(rs.getInt(6));
                sach.setMaNV(rs.getString(7));
                sach.setMaKhuyenMai(rs.getString(8));
                sach.setHinh(rs.getString(9));
                list.add(sach);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<Sach> getTheoTenSach(String tens) {
        List<Sach> list = new ArrayList<>();
        try {
            PreparedStatement pr = con.prepareStatement(getTheoTenSach);
            pr.setString(1, "%" + tens + "%");
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                Sach sach = new Sach();
                sach.setMaSach(rs.getString(1));
                sach.setTenSach(rs.getString(2));
                sach.setTheLoai(rs.getString(3));
                sach.setGiaNhap(rs.getDouble(4));
                sach.setGiaBan(rs.getDouble(5));
                sach.setSoLuong(rs.getInt(6));
                sach.setMaNV(rs.getString(7));
                sach.setMaKhuyenMai(rs.getString(8));
                sach.setHinh(rs.getString(9));
                list.add(sach);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    
    
    public List<Sach> getSumSoLuongSachDaBan() {
        List<Sach> list = new ArrayList<>();
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(getSumSoluongSachDaBan);
            while (rs.next()) {
                Sach sach = new Sach();
                sach.setMaSach(rs.getString(1));
                sach.setSoLuong(rs.getInt(2));
                list.add(sach);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
    
    public List<Sach> getSachBanChay() {
        List<Sach> list = new ArrayList<>();
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(getSachBanChay);
            while (rs.next()) {
                Sach sach = new Sach();
                sach.setMaSach(rs.getString(1));
                sach.setTenSach(rs.getString(2));
                sach.setTheLoai(rs.getString(3));
                sach.setGiaNhap(rs.getDouble(4));
                sach.setGiaBan(rs.getDouble(5));
                sach.setSoLuong(rs.getInt(6));
                sach.setMaNV(rs.getString(7));
                sach.setMaKhuyenMai(rs.getString(8));
                sach.setHinh(rs.getString(9));
                list.add(sach);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
    
    public List<Sach> getSachBanE() {
        List<Sach> list = new ArrayList<>();
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(getSachBanE);
            while (rs.next()) {
                Sach sach = new Sach();
                sach.setMaSach(rs.getString(1));
                sach.setTenSach(rs.getString(2));
                sach.setTheLoai(rs.getString(3));
                sach.setGiaNhap(rs.getDouble(4));
                sach.setGiaBan(rs.getDouble(5));
                sach.setSoLuong(rs.getInt(6));
                sach.setMaNV(rs.getString(7));
                sach.setMaKhuyenMai(rs.getString(8));
                sach.setHinh(rs.getString(9));
                list.add(sach);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
    
    public List<Sach> getSachCoSoLuongMuaNhieuNhat() {
        List<Sach> list = new ArrayList<>();
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(getSachCoLuongMuaNhieuNhat);
            while (rs.next()) {
                Sach sach = new Sach();
                sach.setMaSach(rs.getString(1));
                sach.setTenSach(rs.getString(2));
                sach.setTheLoai(rs.getString(3));
                sach.setGiaNhap(rs.getDouble(4));
                sach.setGiaBan(rs.getDouble(5));
                sach.setSoLuong(rs.getInt(6));
                sach.setMaNV(rs.getString(7));
                sach.setMaKhuyenMai(rs.getString(8));
                sach.setHinh(rs.getString(9));
                list.add(sach);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
    
    public List<Sach> getSachCoMaKhuyenMai() {
        List<Sach> list = new ArrayList<>();
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(getSachCoGiamGia);
            while (rs.next()) {
                Sach sach = new Sach();
                sach.setMaSach(rs.getString(1));
                sach.setTenSach(rs.getString(2));
                sach.setTheLoai(rs.getString(3));
                sach.setGiaNhap(rs.getDouble(4));
                sach.setGiaBan(rs.getDouble(5));
                sach.setSoLuong(rs.getInt(6));
                sach.setMaNV(rs.getString(7));
                sach.setMaKhuyenMai(rs.getString(8));
                sach.setHinh(rs.getString(9));
                list.add(sach);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
    
    public List<Sach> getSachSoLuongConLai(String sl) {
        List<Sach> list = new ArrayList<>();
        try {
            PreparedStatement pr = con.prepareStatement(getTheoTenSach);
            pr.setString(1, sl);
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                Sach sach = new Sach();
                sach.setMaSach(rs.getString(1));
                sach.setTenSach(rs.getString(2));
                sach.setTheLoai(rs.getString(3));
                sach.setGiaNhap(rs.getDouble(4));
                sach.setGiaBan(rs.getDouble(5));
                sach.setSoLuong(rs.getInt(6));
                sach.setMaNV(rs.getString(7));
                sach.setMaKhuyenMai(rs.getString(8));
                sach.setHinh(rs.getString(9));
                list.add(sach);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<Sach> getSachSoluongTheoYeuCau() {
        List<Sach> list = new ArrayList<>();
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(getSoluongSachTheoYeuCau);
            while (rs.next()) {
                Sach sach = new Sach();
                sach.setMaSach(rs.getString(1));
                sach.setTenSach(rs.getString(2));
                sach.setTheLoai(rs.getString(3));
                sach.setGiaNhap(rs.getDouble(4));
                sach.setGiaBan(rs.getDouble(5));
                sach.setSoLuong(rs.getInt(6));
                sach.setMaNV(rs.getString(7));
                sach.setMaKhuyenMai(rs.getString(8));
                sach.setHinh(rs.getString(9));
                list.add(sach);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
    
    public void insertSach(Sach sach) {
        try {
            PreparedStatement pr = con.prepareStatement(insert);
            pr.setString(1, sach.getTenSach());
            pr.setString(2, sach.getTheLoai());
            pr.setDouble(3, sach.getGiaNhap());
            pr.setDouble(4, sach.getGiaBan());
            pr.setInt(5, sach.getSoLuong());
            pr.setString(6, sach.getMaNV());
            pr.setString(7, sach.getMaKhuyenMai());
            pr.setString(8, sach.getHinh());
            pr.executeUpdate();
            pr.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateSach(Sach sach) {

        try {
            PreparedStatement pr = con.prepareStatement(update);
            pr.setString(1, sach.getMaSach());
            pr.setString(2, sach.getTenSach());
            pr.setString(3, sach.getTheLoai());
            pr.setDouble(4, sach.getGiaNhap());
            pr.setDouble(5, sach.getGiaBan());
            pr.setInt(6, sach.getSoLuong());
            pr.setString(7, sach.getMaNV());
            pr.setString(8, sach.getMaKhuyenMai());
            pr.setString(9, sach.getHinh());
            

            pr.executeUpdate();
            pr.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteSach(String maSach) {

        try {
            PreparedStatement pr = con.prepareStatement(delete);
            pr.setString(1, maSach);

            pr.executeUpdate();
            pr.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public List<Sach> searchByID(String barcode){
      List<Sach> listSearch = new ArrayList<>();
       try {
            String sql = "SELECT * FROM sach WHERE masach LIKE '%" + barcode + "%'";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while (rs.next()) {
            Sach sach = new Sach();
            sach.setMaSach(rs.getString(1));
                sach.setTenSach(rs.getString(2));
                sach.setTheLoai(rs.getString(3));
                sach.setGiaNhap(rs.getDouble(4));
                sach.setGiaBan(rs.getDouble(5));
                sach.setSoLuong(rs.getInt(6));
                sach.setMaNV(rs.getString(7));
                sach.setMaKhuyenMai(rs.getString(8));
                sach.setHinh(rs.getString(9));
                listSearch.add(sach);
            }
        
        } catch (Exception e) {
            e.printStackTrace();
        }
       return listSearch;
  }
  
    public List<Sach> searchByName(String tenSach){
      List<Sach> listSearch = new ArrayList<>();
       try {
            String sql = "SELECT * FROM sach WHERE TenSach LIKE ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(1,"%"+tenSach+"%");
            
            ResultSet rs = pr.executeQuery();
            
            while (rs.next()) {
            Sach sach = new Sach();
            sach.setMaSach(rs.getString(1));
                sach.setTenSach(rs.getString(2));
                sach.setTheLoai(rs.getString(3));
                sach.setGiaNhap(rs.getDouble(4));
                sach.setGiaBan(rs.getDouble(5));
                sach.setSoLuong(rs.getInt(6));
                sach.setMaNV(rs.getString(7));
                sach.setMaKhuyenMai(rs.getString(8));
                sach.setHinh(rs.getString(9));
                listSearch.add(sach);
            }
        
        } catch (Exception e) {
            e.printStackTrace();
        }
       return listSearch;
  }
    
    public double getDonGiaByMaSach(String maSach) {
        double donGia = 0;
        String sql = "SELECT GiaBan FROM Sach WHERE MaSach = ?";
        try (
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maSach);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    donGia = rs.getDouble("GiaBan");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return donGia;
    }
    
    //tìm mã sách chuẩn 
    public List<Sach> searchByIDChuan(String barcode){
      List<Sach> listSearch = new ArrayList<>();
       try {
            String sql = "SELECT * FROM sach WHERE masach =? ";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, barcode);
            
            ResultSet rs = st.executeQuery();
            
            while (rs.next()) {
            Sach sach = new Sach();
            sach.setMaSach(rs.getString(1));
                sach.setTenSach(rs.getString(2));
                sach.setTheLoai(rs.getString(3));
                sach.setGiaNhap(rs.getDouble(4));
                sach.setGiaBan(rs.getDouble(5));
                sach.setSoLuong(rs.getInt(6));
                sach.setMaNV(rs.getString(7));
                sach.setMaKhuyenMai(rs.getString(8));
                sach.setHinh(rs.getString(9));
                listSearch.add(sach);
            }
        
        } catch (Exception e) {
            e.printStackTrace();
        }
       return listSearch;
  }
    
    public String getMaSachByTenSach(String tenSach) {
        String maSach = null;
        String sql = "select MaSach from Sach where TenSach = ?";
        try {
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(1, tenSach);
            ResultSet rs = pr.executeQuery();
            if(rs.next()){
                maSach = rs.getString("MaSach");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return maSach;
    }
    
}
