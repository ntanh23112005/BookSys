/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.booksys.dao;

import com.booksys.model.GioHang;
import com.booksys.ui.Login;
import com.booksys.utils.XJdbcHelper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PC
 */
public class GioHangDAO {
    Connection con = XJdbcHelper.getConnection();
    String getAll = "select gh.MaKH, gh.MaSach, s.TenSach, s.GiaBan, s.Hinh from GioHang gh inner join Sach s on gh.MaSach = s.MaSach";
    String insert = "exec proc_ThemGioHang ?, ?";
    String delete = "exec proc_XoaGioHang ?, ?";
    String getTheoMaKH = "select gh.MaKH, gh.MaSach, s.TenSach, s.GiaBan, s.Hinh from GioHang gh inner join Sach s on gh.MaSach = s.MaSach where MaKH = ?";
    
    public List<GioHang> getAll(){
        List<GioHang> list = new ArrayList();
        try{
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(getAll);
            while(rs.next()){
                GioHang gh = new GioHang();
                gh.setMaKH(rs.getString(1));
                gh.setMaSach(rs.getString(2));
                gh.setTenSach(rs.getString(3));
                gh.setGia(rs.getDouble(4));
                gh.setHinh(rs.getString(5));
                list.add(gh);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return list;
    }
    public List<GioHang> getByIDKH(String maKH){
        List<GioHang> list = new ArrayList();
        try{
            Statement st = con.createStatement();
            PreparedStatement pr = con.prepareStatement(getTheoMaKH);
            pr.setString(1, maKH);
            ResultSet rs = pr.executeQuery();
            
            while(rs.next()){
                GioHang gh = new GioHang();
                gh.setMaKH(rs.getString(1));
                gh.setMaSach(rs.getString(2));
                gh.setTenSach(rs.getString(3));
                gh.setGia(rs.getDouble(4));
                gh.setHinh(rs.getString(5));
                list.add(gh);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return list;
    }
    public void insertGioHang(String MaKH, String MaSach) {
        try {
            PreparedStatement pr = con.prepareStatement(insert);
            pr.setString(1, MaKH);
            pr.setString(2, MaSach);
            pr.executeUpdate();
            pr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void deleteGioHang(String MaKH, String MaSach){
        try {
            PreparedStatement pr = con.prepareStatement(delete);
            pr.setString(1, MaKH);
            pr.setString(2, MaSach);
            pr.executeUpdate();
            pr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
