/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.booksys.utils;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author PC
 */
public class XGmail {
    public void guiGmail(String den, String tenTieuDeGmail, String noiDung){
        try{
            String from = "gamedataonin2005@gmail.com";
            String ps = "cgyz ukgg ijls gibq";
            
            Properties props = new Properties();
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "587");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            
            Session s = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, ps);
            }
        });
            Message mes = new MimeMessage(s);
            mes.setFrom(new InternetAddress(from));
            mes.setRecipients(Message.RecipientType.TO, InternetAddress.parse(den));
            mes.setSubject(tenTieuDeGmail);
            mes.setText(String.valueOf(noiDung));
            
            Transport.send(mes);
        } catch(Exception e) {
            System.out.println(e);
        }
    }
}
